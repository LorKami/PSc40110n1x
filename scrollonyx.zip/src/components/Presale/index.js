import React, { useEffect, useState } from 'react';
import './Presale.css'

import Aos from "aos";
import "aos/dist/aos.css";
import { useAccount, useConnect, useEnsName } from 'wagmi'
import { InjectedConnector } from 'wagmi/connectors/injected'
import { Web3Button, Web3Modal } from '@web3modal/react'

const Presale = () => {
    const { address, isConnected } = useAccount()
    const { data: ensName } = useEnsName({ address })
    const { connect } = useConnect({
        connector: new InjectedConnector(),
    })

    useEffect(() => {
        Aos.init({ duration: 900 });
    }, []);

    if (isConnected) return <div>

        <div className='PresaleSec'>
            <div className='PresaleBox'>
                <h2>Script here bro</h2>
            </div>
        </div>

    </div>
    return <div className='Disclaimer'>
        <h2>Please connect your wallet</h2>
        <Web3Button />
        <Web3Modal
            themeVariables={{
                '--w3m-accent-color': '#BCA37F',
                '--w3m-accent-fill-color': '#113946',
                '--w3m-background-color': '#BCA37F',
                '--w3m-logo-image-url': 'https://i.imgur.com/idHNUEn.png'
            }}
        />
    </div>
}


export default Presale