import React from 'react';
import Farm from "../components/Farming";

function Farm() {

    return (
        <div>
            <Farm />
        </div>
    )
}

export default Farm