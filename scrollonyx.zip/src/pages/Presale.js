import React from 'react';
import Presale from "../components/Presale";

function Home() {

    return (
        <div>
            <Presale />
        </div>
    )
}

export default Home