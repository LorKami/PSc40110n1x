import React from 'react';
import Monitor from "../components/Monitor";

function Home() {

  return (
    <div>
      <Monitor />
    </div>
  )
}

export default Home