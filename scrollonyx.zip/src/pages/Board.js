import React from 'react';
import BoardRoom from "../components/BoardRoom";

function Board() {

    return (
        <div>
            <BoardRoom />
        </div>
    )
}

export default Board